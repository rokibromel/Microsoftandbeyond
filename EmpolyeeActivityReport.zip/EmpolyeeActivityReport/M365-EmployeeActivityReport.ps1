# Output Folder
$OutputFolder = "C:\Reports\M365Activity"
New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null

Write-Host "Connecting to Microsoft Graph..."
Connect-MgGraph -Scopes Reports.Read.All -NoWelcome

# Download Reports
Write-Host "Downloading Teams Activity..."
Get-MgReportTeamUserActivityUserDetail `
    -Period D180 `
    -OutFile "$OutputFolder\TeamsActivity.csv"

Write-Host "Downloading Email Activity..."
Get-MgReportEmailActivityUserDetail `
    -Period D180 `
    -OutFile "$OutputFolder\EmailActivity.csv"

Write-Host "Downloading OneDrive Activity..."
Get-MgReportOneDriveActivityUserDetail `
    -Period D180 `
    -OutFile "$OutputFolder\OneDriveActivity.csv"

Write-Host "Downloading SharePoint Activity..."
Get-MgReportSharePointActivityUserDetail `
    -Period D180 `
    -OutFile "$OutputFolder\SharePointActivity.csv"

# Import Data
$Teams = Import-Csv "$OutputFolder\TeamsActivity.csv"
$Email = Import-Csv "$OutputFolder\EmailActivity.csv"
$OneDrive = Import-Csv "$OutputFolder\OneDriveActivity.csv"
$SharePoint = Import-Csv "$OutputFolder\SharePointActivity.csv"

# Get all unique users safely
$Users = @()

$Users += $Teams.'User Principal Name'
$Users += $Email.'User Principal Name'
$Users += $OneDrive.'Owner Principal Name'
$Users += $SharePoint.'Owner Principal Name'

$Users = $Users | Where-Object { $_ -ne $null } | Sort-Object -Unique

$Results = foreach ($User in $Users) {

    $TeamData = $Teams | Where-Object { $_.'User Principal Name' -eq $User }
    $EmailData = $Email | Where-Object { $_.'User Principal Name' -eq $User }
    $ODData = $OneDrive | Where-Object { $_.'Owner Principal Name' -eq $User }
    $SPData = $SharePoint | Where-Object { $_.'Owner Principal Name' -eq $User }

    [PSCustomObject]@{
        UserPrincipalName   = $User

        TeamsChatMessages   = [int]($TeamData.'Team Chat Message Count' | Measure-Object -Sum).Sum
        PrivateChatMessages = [int]($TeamData.'Private Chat Message Count' | Measure-Object -Sum).Sum
        Calls               = [int]($TeamData.'Call Count' | Measure-Object -Sum).Sum
        MeetingsOrganized   = [int]($TeamData.'Meetings Organized Count' | Measure-Object -Sum).Sum
        MeetingsAttended    = [int]($TeamData.'Meetings Attended Count' | Measure-Object -Sum).Sum

        EmailsSent          = [int]($EmailData.'Send Count' | Measure-Object -Sum).Sum
        EmailsReceived      = [int]($EmailData.'Receive Count' | Measure-Object -Sum).Sum

        # FIX: OneDrive safe values
        OneDriveFilesViewed = if ($ODData) { [int]($ODData.'Viewed Or Edited File Count' | Measure-Object -Sum).Sum } else { 0 }
        OneDriveFilesSynced = if ($ODData) { [int]($ODData.'Synced File Count' | Measure-Object -Sum).Sum } else { 0 }
        OneDriveFilesShared = if ($ODData) { [int]($ODData.'Shared Internally File Count' | Measure-Object -Sum).Sum } else { 0 }

        # FIX: SharePoint safe values
        SharePointFilesViewed = if ($SPData) { [int]($SPData.'Viewed Or Edited File Count' | Measure-Object -Sum).Sum } else { 0 }
        SharePointFilesShared = if ($SPData) { [int]($SPData.'Shared Internally File Count' | Measure-Object -Sum).Sum } else { 0 }
    }
}

# Export Final Report
$Results |
    Sort-Object UserPrincipalName |
    Export-Csv "$OutputFolder\M365EmployeeActivity180Days.csv" -NoTypeInformation -Encoding UTF8

Write-Host "Report generated successfully!" -ForegroundColor Green