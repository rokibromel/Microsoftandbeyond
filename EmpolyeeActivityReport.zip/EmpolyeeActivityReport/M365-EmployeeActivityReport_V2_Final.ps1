# M365-EmployeeActivityReport.ps1

```powershell
# Requires:
# Install-Module Microsoft.Graph -Scope CurrentUser

$OutputFolder = "C:\Reports\M365Activity"

if (!(Test-Path $OutputFolder))
{
    New-Item -ItemType Directory -Path $OutputFolder -Force | Out-Null
}

Write-Host "Connecting to Microsoft Graph..." -ForegroundColor Cyan

Connect-MgGraph -Scopes Reports.Read.All -NoWelcome

# ==========================================
# Download Reports
# ==========================================

Write-Host "Downloading Teams Report..." -ForegroundColor Yellow

Get-MgReportTeamUserActivityUserDetail `
    -Period D180 `
    -OutFile "$OutputFolder\TeamsActivity.csv"

Write-Host "Downloading Email Report..." -ForegroundColor Yellow

Get-MgReportEmailActivityUserDetail `
    -Period D180 `
    -OutFile "$OutputFolder\EmailActivity.csv"

Write-Host "Downloading OneDrive Report..." -ForegroundColor Yellow

Get-MgReportOneDriveActivityUserDetail `
    -Period D180 `
    -OutFile "$OutputFolder\OneDriveActivity.csv"

Write-Host "Downloading SharePoint Report..." -ForegroundColor Yellow

Get-MgReportSharePointActivityUserDetail `
    -Period D180 `
    -OutFile "$OutputFolder\SharePointActivity.csv"

# ==========================================
# Import CSV Files
# ==========================================

$Teams      = Import-Csv "$OutputFolder\TeamsActivity.csv"
$Email      = Import-Csv "$OutputFolder\EmailActivity.csv"
$OneDrive   = Import-Csv "$OutputFolder\OneDriveActivity.csv"
$SharePoint = Import-Csv "$OutputFolder\SharePointActivity.csv"

# ==========================================
# Build User List
# ==========================================

$Users = @()

$Users += $Teams.'User Principal Name'
$Users += $Email.'User Principal Name'
$Users += $OneDrive.'User Principal Name'
$Users += $SharePoint.'User Principal Name'

$Users = $Users |
    Where-Object { $_ -and $_ -ne "" } |
    Sort-Object -Unique

# ==========================================
# Merge Reports
# ==========================================

$Results = foreach ($User in $Users)
{
    $TeamData = $Teams |
        Where-Object { $_.'User Principal Name' -eq $User }

    $EmailData = $Email |
        Where-Object { $_.'User Principal Name' -eq $User }

    $ODData = $OneDrive |
        Where-Object { $_.'User Principal Name' -eq $User }

    $SPData = $SharePoint |
        Where-Object { $_.'User Principal Name' -eq $User }

    [PSCustomObject]@{

        UserPrincipalName = $User

        # ====================
        # Teams
        # ====================

        TeamChatMessages =
        if ($TeamData)
        { [int]($TeamData.'Team Chat Message Count') }
        else { 0 }

        PrivateChatMessages =
        if ($TeamData)
        { [int]($TeamData.'Private Chat Message Count') }
        else { 0 }

        Calls =
        if ($TeamData)
        { [int]($TeamData.'Call Count') }
        else { 0 }

        MeetingsOrganized =
        if ($TeamData)
        { [int]($TeamData.'Meetings Organized Count') }
        else { 0 }

        MeetingsAttended =
        if ($TeamData)
        { [int]($TeamData.'Meetings Attended Count') }
        else { 0 }

        # ====================
        # Email
        # ====================

        EmailsSent =
        if ($EmailData)
        { [int]($EmailData.'Send Count') }
        else { 0 }

        EmailsReceived =
        if ($EmailData)
        { [int]($EmailData.'Receive Count') }
        else { 0 }

        EmailsRead =
        if ($EmailData)
        { [int]($EmailData.'Read Count') }
        else { 0 }

        # ====================
        # OneDrive
        # ====================

        OneDriveViewedFiles =
        if ($ODData)
        { [int]($ODData.'Viewed Or Edited File Count') }
        else { 0 }

        OneDriveSyncedFiles =
        if ($ODData)
        { [int]($ODData.'Synced File Count') }
        else { 0 }

        OneDriveSharedInternal =
        if ($ODData)
        { [int]($ODData.'Shared Internally File Count') }
        else { 0 }

        OneDriveSharedExternal =
        if ($ODData)
        { [int]($ODData.'Shared Externally File Count') }
        else { 0 }

        # ====================
        # SharePoint
        # ====================

        SharePointViewedFiles =
        if ($SPData)
        { [int]($SPData.'Viewed Or Edited File Count') }
        else { 0 }

        SharePointSyncedFiles =
        if ($SPData)
        { [int]($SPData.'Synced File Count') }
        else { 0 }

        SharePointSharedInternal =
        if ($SPData)
        { [int]($SPData.'Shared Internally File Count') }
        else { 0 }

        SharePointSharedExternal =
        if ($SPData)
        { [int]($SPData.'Shared Externally File Count') }
        else { 0 }

        SharePointVisitedPages =
        if ($SPData)
        { [int]($SPData.'Visited Page Count') }
        else { 0 }
    }
}

# ==========================================
# Export Final CSV
# ==========================================

$FinalReport = "$OutputFolder\M365EmployeeActivity180Days.csv"

$Results |
    Sort-Object UserPrincipalName |
    Export-Csv $FinalReport -NoTypeInformation -Encoding UTF8

Write-Host ""
Write-Host "==========================================" -ForegroundColor Green
Write-Host "Report Generated Successfully" -ForegroundColor Green
Write-Host $FinalReport -ForegroundColor Cyan
Write-Host "=========================================="
```
